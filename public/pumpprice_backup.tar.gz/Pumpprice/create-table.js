import fetch from 'node-fetch';

const safeUrl = 'https://pvutijbggbbrobjlpwrp.supabase.co';
const serviceRole = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB2dXRpamJnZ2Jicm9iamxwd3JwIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MzMzNTQ2NSwiZXhwIjoyMDg4OTExNDY1fQ.vVw6h-P3q_9p-8uSXXQ-W3pI';

const query = `
CREATE TABLE IF NOT EXISTS public.precomputed_insights (
    id TEXT PRIMARY KEY,
    insight_type TEXT NOT NULL,
    fuel_type VARCHAR(10) NOT NULL,
    data JSONB NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
`;

fetch(`${safeUrl}/rest/v1/rpc/exec_sql`, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'apikey': serviceRole,
    'Authorization': `Bearer ${serviceRole}`
  },
  body: JSON.stringify({ query })
}).then(async (res) => {
  console.log('Status:', res.status);
  console.log('Body:', await res.text());
}).catch(console.error);
