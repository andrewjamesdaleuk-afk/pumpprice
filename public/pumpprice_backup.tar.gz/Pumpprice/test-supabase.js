import fetch from 'node-fetch';

const safeUrl = 'https://pvutijbggbbrobjlpwrp.supabase.co';
const safeKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB2dXRpamJnZ2Jicm9iamxwd3JwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzMzMzU0NjUsImV4cCI6MjA4ODkxMTQ2NX0.aTwY6Ay-TxXz-6fWXgOEm2ozI0qbubOkqQUegaVZQlk';

fetch(`${safeUrl}/rest/v1/rpc/get_brand_leaderboard`, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'apikey': safeKey,
    'Authorization': `Bearer ${safeKey}`
  },
  body: JSON.stringify({ target_fuel_type: 'E10' })
}).then(async (res) => {
  console.log('Status:', res.status);
  console.log('Body:', await res.text());
}).catch(console.error);
