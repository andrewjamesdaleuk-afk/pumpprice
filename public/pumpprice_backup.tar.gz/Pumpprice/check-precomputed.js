import fetch from 'node-fetch';

const safeUrl = 'https://pvutijbggbbrobjlpwrp.supabase.co';
const safeKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB2dXRpamJnZ2Jicm9iamxwd3JwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzMzMzU0NjUsImV4cCI6MjA4ODkxMTQ2NX0.aTwY6Ay-TxXz-6fWXgOEm2ozI0qbubOkqQUegaVZQlk';

async function check() {
  const res = await fetch(`${safeUrl}/rest/v1/precomputed_insights?select=*`, {
    headers: {
      'apikey': safeKey,
      'Authorization': `Bearer ${safeKey}`
    }
  });
  console.log('Status:', res.status);
  const data = await res.json();
  console.log('Table Rows:', data.length);
  console.log('Data:', JSON.stringify(data, null, 2));
}
check();
