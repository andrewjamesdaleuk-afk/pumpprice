import fetch from 'node-fetch';

const safeUrl = 'https://pvutijbggbbrobjlpwrp.supabase.co';
const safeKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB2dXRpamJnZ2Jicm9iamxwd3JwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzMzMzU0NjUsImV4cCI6MjA4ODkxMTQ2NX0.aTwY6Ay-TxXz-6fWXgOEm2ozI0qbubOkqQUegaVZQlk';

fetch(`${safeUrl}/rest/v1/uk_price_history?select=*&order=date.desc&limit=5`, {
  headers: {
    'apikey': safeKey,
    'Authorization': `Bearer ${safeKey}`
  }
}).then(async (res) => {
  console.log('Status:', res.status);
  const data = await res.json();
  console.log('Data:', JSON.stringify(data, null, 2));
}).catch(console.error);
