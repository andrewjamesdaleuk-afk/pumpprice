import fetch from 'node-fetch';

const fetchAllCityStats = async () => {
  const safeUrl = 'https://pvutijbggbbrobjlpwrp.supabase.co';
  const safeKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB2dXRpamJnZ2Jicm9iamxwd3JwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzMzMzU0NjUsImV4cCI6MjA4ODkxMTQ2NX0.aTwY6Ay-TxXz-6fWXgOEm2ozI0qbubOkqQUegaVZQlk';
  
  const response = await fetch(`${safeUrl}/rest/v1/rpc/get_all_city_stats`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'apikey': safeKey,
      'Authorization': `Bearer ${safeKey}`
    }
  });
  const data = await response.json();
  return data || [];
};

fetchAllCityStats().then(console.log).catch(console.error);
