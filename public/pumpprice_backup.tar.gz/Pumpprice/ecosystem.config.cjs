module.exports = {
  apps: [
    {
      name: "pumpprice-ui",
      cwd: "./frontend",
      script: "npm",
      args: "run preview",
      env: {
        NODE_ENV: "production",
        PORT: 3005
      },
      error_file: "/root/.pm2/logs/pumpprice-ui-error.log",
      out_file: "/root/.pm2/logs/pumpprice-ui-out.log"
    },
    {
      name: "pumpprice-tunnel",
      script: "/docker/openclaw-r4li/data/.openclaw/workspace/cf-bin/usr/bin/cloudflared",
      args: "tunnel --config /docker/openclaw-r4li/data/.cloudflared/config.yml run 3142573d-8225-4982-acd3-9cde6585bd57",
      error_file: "/root/.pm2/logs/pumpprice-tunnel-error.log",
      out_file: "/root/.pm2/logs/pumpprice-tunnel-out.log"
    },
    {
      name: "pumpprice-vite",
      cwd: "./frontend",
      script: "npm",
      args: "run dev",
      env: {
        NODE_ENV: "development"
      },
      error_file: "/root/.pm2/logs/pumpprice-vite-error.log",
      out_file: "/root/.pm2/logs/pumpprice-vite-out.log"
    },
    {
      name: "pumpprice-ngrok",
      cwd: "./frontend",
      script: "/docker/openclaw-r4li/data/.npm-global/lib/node_modules/ngrok/bin/ngrok",
      args: "http --url=gentlemanlike-tantalizing-solange.ngrok-free.dev 5173 --config=/docker/openclaw-r4li/data/.config/ngrok/ngrok.yml",
      error_file: "/root/.pm2/logs/pumpprice-ngrok-error.log",
      out_file: "/root/.pm2/logs/pumpprice-ngrok-out.log"
    }
  ]
};
