import fetch from 'node-fetch';
import polyline from '@mapbox/polyline';

const fetchRankedCities = async (type, fuelType = 'E10') => {
  const safeUrl = 'https://pvutijbggbbrobjlpwrp.supabase.co';
  const safeKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB2dXRpamJnZ2Jicm9iamxwd3JwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzMzMzU0NjUsImV4cCI6MjA4ODkxMTQ2NX0.aTwY6Ay-TxXz-6fWXgOEm2ozI0qbubOkqQUegaVZQlk';
  const rpcName = type === 'cheapest' ? 'get_cheapest_cities' : 'get_most_expensive_cities';
  const response = await fetch(`${safeUrl}/rest/v1/rpc/${rpcName}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'apikey': safeKey,
      'Authorization': `Bearer ${safeKey}`
    },
    body: JSON.stringify({ target_fuel_type: fuelType })
  });
  const data = await response.json();
  return data || [];
};

async function run() {
  const exp = await fetchRankedCities('expensive');
  console.log('Expensive:', exp);
  const cheap = await fetchRankedCities('cheapest');
  console.log('Cheapest:', cheap);
}
run();
