import fetch from 'node-fetch';
import polyline from '@mapbox/polyline';

const fetchStationsNearRoute = async (routeGeometry, fuelType, bufferMeters = 8046.72) => {
  const safeUrl = 'https://pvutijbggbbrobjlpwrp.supabase.co';
  const safeKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB2dXRpamJnZ2Jicm9iamxwd3JwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzMzMzU0NjUsImV4cCI6MjA4ODkxMTQ2NX0.aTwY6Ay-TxXz-6fWXgOEm2ozI0qbubOkqQUegaVZQlk';
  const fuelTypeParam = fuelType === 'petrol' ? 'E10' : 'B7';
  
  const response = await fetch(`${safeUrl}/functions/v1/route-matcher`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${safeKey}`,
    },
    body: JSON.stringify({
      routeGeometry,
      fuelType: fuelTypeParam,
      bufferMeters
    })
  });
  if (!response.ok) return null;
  const data = await response.json();
  return data.stations || [];
};

async function run() {
  const pointPolyline = polyline.encode([[54.5975805, -5.9277097], [54.5976805, -5.9276097]]); // Belfast
  const stations = await fetchStationsNearRoute(pointPolyline, 'petrol');
  console.log("Belfast stations sample:", stations[0]);
}
run();
